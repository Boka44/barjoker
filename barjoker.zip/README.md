"# barjoker" 
